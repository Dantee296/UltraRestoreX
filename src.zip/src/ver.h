//
// Created by 010010 on 03/05/2020.
// This header file should be included in all C files and defines version information and other key parameters.
//

#define VER 1
#define DEBUG 1
#define IOS 13

#ifndef SRC_VER_H
#define SRC_VER_H

#endif //SRC_VER_H
